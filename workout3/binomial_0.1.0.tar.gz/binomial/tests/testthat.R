library(testthat)
test_check("binomial")
